AUBER SNACKS — PROJET ANDROID

CONTENU
- Application Android native (Java) avec interface de jeu hors ligne intégrée.
- Accueil, niveaux débutant/intermédiaire/expert, score, meilleur score, progression locale.
- Paramètres et page À propos.

OUVRIR ET CONSTRUIRE L'APK
1. Installer Android Studio sur un ordinateur.
2. Décompresser AuberSnacks_Android.zip.
3. Dans Android Studio, choisir Open puis sélectionner le dossier AuberSnacks_Android.
4. Attendre la synchronisation Gradle et l'installation du SDK Android 35 si Android Studio le demande.
5. Menu Build > Build Bundle(s) / APK(s) > Build APK(s).
6. L'APK de test sera généré dans app/build/outputs/apk/debug/app-debug.apk.

POUR GOOGLE PLAY
Générer une version signée via Build > Generate Signed Bundle / APK > Android App Bundle (AAB).
La publication exige un compte Google Play Console, les informations de l'éditeur, la fiche Play Store et les déclarations de conformité demandées par Google.

NOTE
Ce paquet contient le projet Android Studio prêt à compiler. Il ne contient pas encore un APK compilé, car la compilation Android nécessite le SDK Android et l'environnement Gradle/Android Studio.


COMPILATION SANS ORDINATEUR (GITHUB ACTIONS)
Le dossier .github/workflows contient android.yml. Après avoir envoyé le contenu du projet dans un dépôt GitHub, ouvrir l'onglet Actions et lancer « Build AUBER SNACKS APK ». Télécharger ensuite l'artefact AUBER-SNACKS-APK.
